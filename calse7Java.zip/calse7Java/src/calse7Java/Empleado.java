package calse7Java;

import java.util.ArrayList;

public class Empleado {

	private String nombre;
	private String dni;
	private int edad;

	// Por default, si se crea un objeto empleado con el constructor vac�o, se
	// completa con estos valores.
	public Empleado() {
		this.nombre = "Santi";
		this.dni = "39593729";
		this.edad = 22;
	}

	public Empleado(String nombre, String dni, int edad) {
		this.nombre = nombre;
		this.dni = dni;
		this.edad = edad;
	}

	@Override
	public String toString() {
		return "Empleado [nombre=" + nombre + ", dni=" + dni + ", edad=" + edad + "]";
	}

	public static void informarDatosDeEmpleados(ArrayList<Empleado> losEmpleados) {

		for (int i = 0; i < losEmpleados.size(); i++) {

			System.out.println(losEmpleados.get(i));

		}

	}

	public static ArrayList<Empleado> obtenerDatosDeEmpleadosMenosDe30(ArrayList<Empleado> losEmpleados) {

		ArrayList<Empleado> empleadosMenores30 = new ArrayList<Empleado>();

		for (int i = 0; i < losEmpleados.size(); i++) {

			if (losEmpleados.get(i).getEdad() < 30) {

				empleadosMenores30.add(losEmpleados.get(i));

			}

		}

		return empleadosMenores30;

	}

	public String getNombre() {
		return nombre;
	}

	public String getDni() {
		return dni;
	}

	public int getEdad() {
		return edad;
	}

}
