package test;

import java.util.ArrayList;

import calse7Java.Empleado;

public class Empresa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 * Test de la clase Empleado
		Empleado empleado1 = new Empleado();
		
		Empleado empleado2 = new Empleado("Juan Pablo", "99999999", 29);
		
		System.out.println(empleado1);
		System.out.println(empleado2); */
		
		Empleado empleado1 = new Empleado();
		Empleado empleado2 = new Empleado("Juan Pablo", "99999999", 29);
		Empleado empleado3 = new Empleado("Guille", "69696969", 29);
		Empleado empleado4 = new Empleado("Dani", "01010101", 45);
		Empleado empleado5 = new Empleado("Pepe", "33333333", 33);
		Empleado empleado6 = new Empleado("Lali", "88888888", 29);
		
		ArrayList<Empleado> losEmpleados = new ArrayList<Empleado>();
		
		losEmpleados.add(empleado1);
		losEmpleados.add(empleado2);
		losEmpleados.add(empleado3);
		losEmpleados.add(empleado4);
		losEmpleados.add(empleado5);
		losEmpleados.add(empleado6);
		
		/*
		for(int i = 0; i<losEmpleados.size(); i++) {
			
			System.out.println(losEmpleados.get(i));
			
		} */
		
		Empleado.informarDatosDeEmpleados(losEmpleados);
		
		System.out.println("-----------------------------------------------");
		
		System.out.println("Cantidad de empleados: " + losEmpleados.size());
		
		System.out.println("-----------------------------------------------");
		
		System.out.println("Empleados menores de 30 a�os:"); //Probar con un method en Empleado
		
		/*
		for(int i = 0; i<losEmpleados.size(); i++) {
			
			if(losEmpleados.get(i).getEdad() < 30) {
				
				System.out.println(losEmpleados.get(i));
				
			}
			
		} */
		
		Empleado.informarDatosDeEmpleados(Empleado.obtenerDatosDeEmpleadosMenosDe30(losEmpleados));		

	}

}
