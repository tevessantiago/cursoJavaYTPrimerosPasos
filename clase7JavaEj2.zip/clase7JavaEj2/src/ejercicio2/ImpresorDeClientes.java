package ejercicio2;

import java.util.ArrayList;
import java.util.Iterator;

public class ImpresorDeClientes {

	public static void main(String[] args) {

		Cliente cliente1 = new Cliente("Citi", "Pueyrredon 3858");
		Cliente cliente2 = new Cliente("HSBC", "Lavalle 2547");
		Cliente cliente3 = new Cliente("Microsoft", "Florida 8578");
		Cliente cliente4 = new Cliente("Apple", "Guido 6875");
		Cliente cliente5 = new Cliente("Sauron", "9 de Julio 9053");

		ArrayList<Cliente> losClientes = new ArrayList<Cliente>();

		losClientes.add(cliente1);
		losClientes.add(cliente2);
		losClientes.add(cliente3);
		losClientes.add(cliente4);
		losClientes.add(cliente5);

		Iterator<Cliente> iterador = (Iterator<Cliente>) losClientes.iterator();

		while (iterador.hasNext()) {
			System.out.println(iterador.next());
		}

	}

}
